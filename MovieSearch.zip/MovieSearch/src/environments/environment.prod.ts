export const environment = {
  production: true,
  urlAddress: 'https://api.themoviedb.org/3/movie/550?api_key=21c5668c9871e9e65920c43f7af6d078s'
};
