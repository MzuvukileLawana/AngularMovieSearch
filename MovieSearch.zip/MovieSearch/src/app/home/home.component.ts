import { Component, OnInit} from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public filtervalue: string;
  public txtSearch: string;
 
  constructor() { }

  ngOnInit() {
  }

  applyFilter(filterInputValue: string) {
      filterInputValue = filterInputValue.trim();
      filterInputValue = filterInputValue.toLowerCase();
      this.filtervalue = filterInputValue;
  
  }
}
