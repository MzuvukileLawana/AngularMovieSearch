import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {

  constructor(private http: HttpClient) { }

  public getMovie() {
    return this.http.get(environment.urlAddress).pipe(
      map((res: any) => res),
      catchError(this.handleError)
  );
  }

  private handleError(err) {
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
        errorMessage = 'An error occurred: ' + err.error.message;
    } else {
        errorMessage = err.status + ' ' + err.message;
    }
    console.error(err);
    return throwError(errorMessage);
}


}
