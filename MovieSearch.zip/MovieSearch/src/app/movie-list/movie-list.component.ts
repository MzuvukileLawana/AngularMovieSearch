import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { RepositoryService} from './../shared/repository.service';
import { MatTableDataSource, MatSort } from '@angular/material';
import {Movie} from '../models/movie.model';
import { stringify } from 'querystring';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
  name: any;
  logoPath: any;
  movieImage: any;
  originCountry: any;
  data:any;
  public displayedColumns = ['Results'];
  public dataSource = new MatTableDataSource<Movie>();
  public matTableDataSource;
  @ViewChild(MatSort) sort: MatSort;

  public movieURL = "https://image.tmdb.org/t/p/w500"; 
  
  constructor(private repoService: RepositoryService) { }

  ngOnInit() {
    
  this.data;
    this.repoService.getMovie().subscribe(res => {
      this.dataSource.data = res["production_companies"] as Movie[];
      this.dataSource.sort = this.sort;
     
    })
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  @Input()
  set filtervalue(filtervalue: string) {

    if(filtervalue === ""){
      this.data = 0;
    }
    else
    {    
      debugger;
      this.dataSource.filter = filtervalue;
      this.data =  this.dataSource.filteredData;
    }
    
    
  }

  getDetails(row: any){
 
    this.data = 0;
    var id = Object.values(row)[0];
    this.logoPath = Object.values(row)[1];
    this.name = Object.values(row)[2];
    this.originCountry = Object.values(row)[3];

    this.movieImage = this.movieURL + this.logoPath;

  }
}
